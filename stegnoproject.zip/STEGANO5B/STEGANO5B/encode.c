/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */

#include <stdio.h>
#include "encode.h"
#include "types.h"
#include <string.h>
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    printf("height = %u\n", height);

    // Return image capacity
    uint size = width * height * 3;

rewind(fptr_image);

return size;
}

uint get_file_size(FILE *fptr)
{
    /* Move file pointer to the end */
    fseek(fptr, 0, SEEK_END);

    /* Get the file size */
    uint size = ftell(fptr);

    /* Move file pointer back to the beginning */
    rewind(fptr);

    /* Return the file size */
    return size;
}
/*
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */


Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    char *ptr;

    /* Step 1: Validate source image file (.bmp) */
    if(argv[2] != NULL)
{
    ptr = strstr(argv[2], ".bmp");
}
else
{
    return e_failure;
}

    if (ptr != NULL && strcmp(ptr, ".bmp") == 0)
    {
        printf("Source image file is valid\n");
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        printf("Error: Source image should be a .bmp file\n");
        return e_failure;
    }

    /* Step 2: Validate secret file (.txt) */
    
    if(argv[3] != NULL)
{
    ptr = strstr(argv[3], ".txt");
}
else
{
    return e_failure;
}

    if (ptr != NULL && strcmp(ptr, ".txt") == 0)
    {
        printf("Secret file is valid\n");
        encInfo->secret_fname = argv[3];

        /* Store secret file extension */
        ptr = strrchr(argv[3], '.');
        if (ptr != NULL)
        {
            strcpy(encInfo->extn_secret_file, ptr);
        }
    }
    else
    {
        printf("Error: Secret file should be a .txt file\n");
        return e_failure;
    }

    /* Step 3: Validate destination image file */
    if (argv[4] == NULL)
    {
        encInfo->dest_image_fname = "stego.bmp";
    }
    else
    {
       if(argv[4] != NULL)
{
    ptr = strstr(argv[4], ".bmp");
}
else
{
    return e_failure;
}

        if (ptr != NULL && strcmp(ptr, ".bmp") == 0)
        {
            encInfo->dest_image_fname = argv[4];
        }
        else
        {
            printf("Error: Output image should be a .bmp file\n");
            return e_failure;
        }
    }

    /* Step 4: Return success */
    return e_success;
} 



Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname,"rb");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

        return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname,"rb");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

        return e_failure;
    }

    // Stego Image file
    encInfo->fptr_dest_image = fopen(encInfo->dest_image_fname,"wb");
    // Do Error handling
    if (encInfo->fptr_dest_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->dest_image_fname);

        return e_failure;
    }

    // No failure return e_success
    return e_success;
}



Status check_capacity(EncodeInfo *encInfo)
{
    /* Get image capacity */
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);

    /* Get secret file size */
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    /* Calculate total bytes to be encoded */
    int total_size = strlen(MAGIC_STRING)
                   + sizeof(int)
                   + strlen(encInfo->extn_secret_file)
                   + sizeof(int)
                   + encInfo->size_secret_file;

    /* Check image capacity */
    if (encInfo->image_capacity > (total_size * 8))
    {
        return e_success;
    }

    return e_failure;
}


Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    /* Step 1: Move source file pointer to the beginning */
    rewind(fptr_src_image);

    /* Step 2: Create a buffer for BMP header */
    char imageBuffer[54];

   if(fread(imageBuffer,54,1,fptr_src_image)!=1)
    return e_failure;

if(fwrite(imageBuffer,54,1,fptr_dest_image)!=1)
    return e_failure;

    /* Step 5: Check the file pointer positions */
    if (ftell(fptr_src_image) == 54 && ftell(fptr_dest_image) == 54)
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}



Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    char imageBuffer[8];

    /* Encode each character of the magic string */
    for (int i = 0; magic_string[i] != '\0'; i++)
    {
        /* Read 8 bytes from source image */
        fread(imageBuffer, 8, 1, encInfo->fptr_src_image);

        /* Encode one character into the LSBs */
        encode_byte_to_lsb(magic_string[i], imageBuffer);

        /* Write modified bytes to destination image */
        fwrite(imageBuffer, 8, 1, encInfo->fptr_dest_image);
    }

    /* Check file pointer positions */
    if (ftell(encInfo->fptr_src_image) == ftell(encInfo->fptr_dest_image))
    {
        return e_success;
    }

    return e_failure;
}

Status encode_secret_file_extn_size(int size, EncodeInfo *encInfo)
{
    /* Step 1: Create a buffer of 32 bytes */
    char imageBuffer[32];

    /* Step 2: Read 32 bytes from source image */
    fread(imageBuffer, 32, 1, encInfo->fptr_src_image);

    /* Step 3: Encode the extension size into the LSBs */
    encode_size_to_lsb(size, imageBuffer);

    /* Step 4: Write the modified buffer to destination image */
    fwrite(imageBuffer, 32, 1, encInfo->fptr_dest_image);

    /* Step 5: Check the file pointer positions */
    if (ftell(encInfo->fptr_src_image) == ftell(encInfo->fptr_dest_image))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    /* Step 1: Create a buffer of 8 bytes */
    char imageBuffer[8];

    /* Step 2: Encode each character of the file extension */
    for (int i = 0; file_extn[i] != '\0'; i++)
    {
        /* Step 3: Read 8 bytes from source image */
        fread(imageBuffer, 8, 1, encInfo->fptr_src_image);

        /* Step 4: Encode one character into the LSBs */
        encode_byte_to_lsb(file_extn[i], imageBuffer);

        /* Step 5: Write the modified bytes to destination image */
        fwrite(imageBuffer, 8, 1, encInfo->fptr_dest_image);
    }

    /* Step 6: Check file pointer positions */
    if (ftell(encInfo->fptr_src_image) == ftell(encInfo->fptr_dest_image))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}


Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    /* Step 1: Create a buffer of 32 bytes */
    char imageBuffer[32];

    /* Step 2: Read 32 bytes from source image */
    fread(imageBuffer, 32, 1, encInfo->fptr_src_image);

    /* Step 3: Encode the secret file size into the LSBs */
    encode_size_to_lsb((int)file_size,imageBuffer);

    /* Step 4: Write the modified buffer to destination image */
    fwrite(imageBuffer, 32, 1, encInfo->fptr_dest_image);

    /* Step 5: Check the file pointer positions */
    if (ftell(encInfo->fptr_src_image) == ftell(encInfo->fptr_dest_image))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}


Status encode_secret_file_data(EncodeInfo *encInfo)
{
    /* Step 1: Move secret file pointer to beginning */
    rewind(encInfo->fptr_secret);

    /* Step 2: Declare array to store secret file data */
   char secret_file_data[encInfo->size_secret_file + 1];

    /* Step 3: Read secret file data */
    fread(secret_file_data, encInfo->size_secret_file, 1, encInfo->fptr_secret);
    secret_file_data[encInfo->size_secret_file] = '\0';

    char imageBuffer[8];

    /* Step 4: Encode each character */
    for (int i = 0; i < encInfo->size_secret_file; i++)
    {
        /* Read 8 bytes from source image */
        fread(imageBuffer, 8, 1, encInfo->fptr_src_image);

        /* Encode one character */
        encode_byte_to_lsb(secret_file_data[i], imageBuffer);

        /* Write encoded bytes to destination image */
        fwrite(imageBuffer, 8, 1, encInfo->fptr_dest_image);
    }

    /* Step 5: Check file pointer positions */
    if (ftell(encInfo->fptr_src_image) == ftell(encInfo->fptr_dest_image))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    /* Step 1: Generate loop for 8 bits */
    for (int i = 0; i < 8; i++)
    {
        /* Step 2: Get one bit from data */
        int bit = (data >> i) & 1;

        /* Step 3: Clear the LSB of image_buffer[i] */
        image_buffer[i] = image_buffer[i] & (~1);

        /* Step 4: Set the bit into the LSB */
        image_buffer[i] = image_buffer[i] | bit;
    }

    return e_success;
}

Status encode_size_to_lsb(int size, char *imageBuffer)
{
    /* Step 1: Generate loop for 32 bits */
    for (int i = 0; i < 32; i++)
    {
        /* Step 2: Get one bit from size */
        int bit = (size >> i) & 1;

        /* Step 3: Clear the LSB of imageBuffer[i] */
        imageBuffer[i] = imageBuffer[i] & (~1);

        /* Step 4: Set the bit into the LSB */
        imageBuffer[i] = imageBuffer[i] | bit;
    }

    return e_success;
}


Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    /* Step 1: Declare a buffer */
    char buffer;

    /* Step 2: Read until End of File */
    while (fread(&buffer, 1, 1, fptr_src) == 1)
    {
        /* Step 3: Write each byte to destination */
        fwrite(&buffer, 1, 1, fptr_dest);
    }

    /* Step 4: Return success */
    return e_success;
}


Status do_encoding(EncodeInfo *encInfo)
{
    printf("\n<----------- Encoding Started ----------->\n");

    /* Step 1: Open files */
    if (open_files(encInfo) == e_success)
    {
        printf("Files opened successfully\n");
    }
    else
    {
        printf("Error: Unable to open files\n");
        return e_failure;
    }

    /* Step 2: Check capacity */
    if (check_capacity(encInfo) == e_success)
    {
        printf("Image has enough capacity\n");
    }
    else
    {
        printf("Error: Image does not have enough capacity\n");
        return e_failure;
    }

    /* Step 3: Copy BMP header */
    if (copy_bmp_header(encInfo->fptr_src_image,
                        encInfo->fptr_dest_image) == e_success)
    {
        printf("BMP header copied successfully\n");
    }
    else
    {
        printf("Error: BMP header copy failed\n");
        return e_failure;
    }

    /* Step 4: Encode magic string */
    if (encode_magic_string(MAGIC_STRING, encInfo) == e_success)
    {
        printf("Magic string encoded successfully\n");
    }
    else
    {
        printf("Error: Magic string encoding failed\n");
        return e_failure;
    }

    /* Step 5: Get extension size */
    int extn_size = strlen(encInfo->extn_secret_file);

    /* Step 6: Encode extension size */
    if (encode_secret_file_extn_size(extn_size, encInfo) == e_success)
    {
        printf("Extension size encoded successfully\n");
    }
    else
    {
        printf("Error: Extension size encoding failed\n");
        return e_failure;
    }

    /* Step 7: Encode extension */
    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_success)
    {
        printf("Extension encoded successfully\n");
    }
    else
    {
        printf("Error: Extension encoding failed\n");
        return e_failure;
    }

    /* Step 8: Encode secret file size */
    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_success)
    {
        printf("Secret file size encoded successfully\n");
    }
    else
    {
        printf("Error: Secret file size encoding failed\n");
        return e_failure;
    }

    /* Step 9: Encode secret file data */
    if (encode_secret_file_data(encInfo) == e_success)
    {
        printf("Secret file data encoded successfully\n");
    }
    else
    {
        printf("Error: Secret file data encoding failed\n");
        return e_failure;
    }

    /* Step 10: Copy remaining image data */
    if (copy_remaining_img_data(encInfo->fptr_src_image,
                                encInfo->fptr_dest_image) == e_success)
    {
        printf("Remaining image data copied successfully\n");
    }
    else
    {
        printf("Error: Copying remaining image data failed\n");
        return e_failure;
    }

    /* Close all files */
    fclose(encInfo->fptr_src_image);
    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_dest_image);

    printf("\nEncoding completed successfully.\n");

    return e_success;
}