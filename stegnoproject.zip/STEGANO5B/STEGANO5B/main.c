
/*
NAME: Harsh Patil
Date: 23/07/2026
File: main.c


DESCRIPTION :
This file contains all the functions required for decoding data hidden inside
a BMP image using the Least Significant Bit (LSB) steganography technique.
It performs argument validation, opens the required files, skips the BMP header,
decodes the magic string to verify the hidden data, extracts the secret file
extension, secret file size, and secret file contents, and writes the recovered
data into the output file. The implementation follows a modular approach with
separate functions for each decoding operation.
*/


#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include<string.h>
OperationType check_operation_type(char *);


Status main(int argc, char *argv[])
{
    /* Step 1: Check the number of command-line arguments */
    if (argc <= 4)
    {
        /* Step 2: Check the operation type */
        if (check_operation_type(argv[1]) == e_encode)
        {
            /* Step 3: Declare the EncodeInfo structure */
            EncodeInfo encInfo;

            /* Step 4: Read and validate the arguments */
            if (read_and_validate_encode_args(argv, &encInfo) == e_success)
            {
                /* Step 5: Perform encoding */
                if (do_encoding(&encInfo) == e_success)
                {
                    printf("Encoding completed successfully\n");
                    return e_success;
                }
                else
                {
                    printf("Encoding failed\n");
                    return e_failure;
                }
            }
            else
            {
                printf("Error: Invalid encoding arguments\n");
                return e_failure;
            }
        }

        else if (check_operation_type(argv[1]) == e_decode)
        {
            /* Step 3: Declare the EncodeInfo structure */
            DecodeInfo decInfo;

            /* Step 4: Read and validate the arguments */
            if (read_and_validate_decode_args(argv, &decInfo) == e_success)
            {
                /* Step 5: Perform encoding */
                if (do_decoding(&decInfo) == e_success)
                {
                    printf("Decoding completed successfully\n");
                    return e_success;
                }
                else
                {
                    printf("Decoding failed\n");
                    return e_failure;
                }
            }
            else
            {
                printf("Error: Invalid encoding arguments\n");
                return e_failure;
            }
        }
        else
        {
            printf("Unsupported operation\n");
            return e_failure;
        }
    }
    else
    {
        printf("Usage: For Encoding - ./a.out -e <source.bmp> <secret.txt> [output.bmp]\n");
        printf("Usage: For Decoding - ./a.out -d <source.bmp> [output.txt]\n");
        return e_failure;
    }
}

#include <string.h>

OperationType check_operation_type(char *symbol)
{
    /* Step 1: Check whether the symbol is "-e" */
    if (strcmp(symbol, "-e") == 0)
    {
        return e_encode;
    }

    /* Step 2: Check whether the symbol is "-d" */
    else if (strcmp(symbol, "-d") == 0)
    {
        return e_decode;
    }

    /* Step 3: Unsupported operation */
    else
    {
        return e_unsupported;
    }
}