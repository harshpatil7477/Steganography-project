#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"



/* Validate decode arguments */
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
   char *ptr = strrchr(argv[2], '.');

if(ptr == NULL || strcmp(ptr, ".bmp") != 0)
{
    return e_failure;
}

    decInfo->stego_image_fname = argv[2];

    if(argv[3] != NULL)
        decInfo->output_fname = argv[3];
    else
        decInfo->output_fname = "decoded";

    return e_success;
}


/* Open stego image */
Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname,"rb");

    if(decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        return e_failure;
    }

    return e_success;
}


/* Skip BMP header */
Status skip_bmp_header(FILE *fptr_stego_image)
{
    fseek(fptr_stego_image,54,SEEK_SET);

    return e_success;
}


/* Decode one byte from 8 image bytes */
Status decode_byte_from_lsb(char *data, char *image_buffer)
{
    *data = 0;

for(int i = 0; i < 8; i++)
{
    *data |= ((image_buffer[i] & 1) << i);
}

    return e_success;
}

/* Decode data from image */
Status decode_data_from_image(char *buffer, int size, DecodeInfo *decInfo)
{
    char image_buffer[8];

    for(int i=0;i<size;i++)
    {
        fread(image_buffer,8,1,decInfo->fptr_stego_image);

        decode_byte_from_lsb(&buffer[i],image_buffer);
    }

    return e_success;
}


/* Decode magic string */
Status decode_magic_string(char *magic_string, DecodeInfo *decInfo)
{
    int len = strlen(MAGIC_STRING);

    decode_data_from_image(magic_string,len,decInfo);

    magic_string[len]='\0';

    if(strcmp(magic_string,MAGIC_STRING)==0)
        return e_success;

    return e_failure;
}


/* Decode extension size */
Status decode_secret_file_extn_size(int *extn_size, DecodeInfo *decInfo)
{
    if(decode_int_from_lsb(extn_size, decInfo->fptr_stego_image) == e_failure)
    {
        return e_failure;
    }

    decInfo->extn_size = *extn_size;

    return e_success;
}


/* Decode extension */
Status decode_secret_file_extn(char *extn, int extn_size, DecodeInfo *decInfo)
{
    decode_data_from_image(extn,extn_size,decInfo);

    extn[extn_size]='\0';

    return e_success;
}


/* Decode integer from image */
Status decode_int_from_lsb(int *data, FILE *fptr_stego_image)
{
    char buffer[32];

    fread(buffer,32,1,fptr_stego_image);

    *data = 0;

for(int i = 0; i < 32; i++)
{
    *data |= ((buffer[i] & 1) << i);
}

    return e_success;
}


/* Decode secret file size */
Status decode_secret_file_size(int *file_size, DecodeInfo *decInfo)
{
    decode_int_from_lsb(file_size,decInfo->fptr_stego_image);

    decInfo->size_secret_file = *file_size;

    return e_success;
}


/* Decode secret file data */
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char ch;

    for(long i=0;i<decInfo->size_secret_file;i++)
    {
        char image_buffer[8];

        fread(image_buffer,8,1,decInfo->fptr_stego_image);

        decode_byte_from_lsb(&ch,image_buffer);

        fwrite(&ch,1,1,decInfo->fptr_output);
    }

    return e_success;
}


/* Complete decoding */
Status do_decoding(DecodeInfo *decInfo)
{

    if(open_decode_files(decInfo)==e_failure)
        return e_failure;


    if(skip_bmp_header(decInfo->fptr_stego_image) == e_failure)
    return e_failure;



    if(decode_magic_string(decInfo->magic,decInfo)==e_failure)
    {
        printf("Magic string mismatch\n");
        return e_failure;
    }


   if(decode_secret_file_extn_size(&decInfo->extn_size, decInfo) == e_failure)
    return e_failure;



   if(decode_secret_file_extn(decInfo->extn_secret_file,
                           decInfo->extn_size,
                           decInfo) == e_failure)
    return e_failure;



    char output_file[50];

    strcpy(output_file,decInfo->output_fname);

    strcat(output_file,decInfo->extn_secret_file);



    decInfo->fptr_output=fopen(output_file,"wb");

    if(decInfo->fptr_output==NULL)
        return e_failure;



    int size;

   if(decode_secret_file_size(&size,decInfo) == e_failure)
    return e_failure;



   if(decode_secret_file_data(decInfo) == e_failure)
    return e_failure;



    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_output);


    printf("Decoding successful\n");


    return e_success;
}